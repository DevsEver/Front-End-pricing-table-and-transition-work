(function ($){
    "use strict";
    
    jQuery(document).ready(function($){
        
        
    
    jQuery(window).load(function(){
        
    
    });
    
}(jQuery));